# WAYT Recesso Online — contesto di progetto

Plugin WordPress/WooCommerce che implementa la **funzione di recesso elettronica** richiesta dall'**art. 54-bis del Codice del Consumo** (D.Lgs 209/2025, recepimento della **Direttiva UE 2023/2673**), in vigore dal **19 giugno 2026**. Distribuito da **WAYT** sotto licenza GPL-2.0-or-later. È software libero e gratuito: nessuna funzione a pagamento.

## Stack e vincoli

- PHP **8.0+**, WordPress **6.2+**, WooCommerce **7.0+**, compatibile **HPOS**.
- **Zero dipendenze runtime** e **nessuna chiamata di rete** per le funzioni core (incluso il generatore PDF, scritto a mano).
- Architettura a **singleton** (`WAYT_Recesso_Online`), classe PDF separata (`WAYT_Recesso_PDF`).
- Flusso utente **interamente server-side, senza JavaScript** e senza login del cliente.

## Mappa dei file

- `wayt-recesso-online.php` — file principale: hook, flusso dichiarazione/conferma, registro, admin, impostazioni, email, esclusioni, rimborso, blocchi.
- `includes/class-wayt-recesso-pdf.php` — generatore PDF/1.4 dependency-free (font core, encoding WinAnsi).
- `uninstall.php` — pulizia condizionale (purge opt-in; il registro è prova di conformità).
- `languages/wayt-recesso.pot` — template di traduzione (text domain `wayt-recesso`).

## Dati e convenzioni

- Tabella audit: `{prefix}wayt_recesso_requests`. Opzioni: `wayt_recesso_options`. Stato ordine: `wc-recesso`.
- Meta ordine: `_wayt_recesso`, `_wayt_recesso_date`. Meta prodotto: `_wayt_recesso_excluded`.
- Prefissi obbligatori per globali/classi/costanti: `wayt_recesso` / `WAYT_Recesso` / `WAYT_RECESSO`.
- Tutte le stringhe utente sono internazionalizzate con il text domain `wayt-recesso`.

## Regole di sicurezza (non negoziabili)

1. **Sanitizza** ogni input (`sanitize_*`, `absint`, `wp_unslash`).
2. **Escapa** ogni output (`esc_html`, `esc_attr`, `esc_url`).
3. **Nonce** su ogni azione che cambia stato (form, admin-post, link azione).
4. **Capability check** sulle azioni admin (`manage_woocommerce`).
5. **Query preparate** (`$wpdb->prepare`) per ogni query con input.

## Comandi

```bash
composer install
composer run lint      # PHP_CodeSniffer (WordPress-Extra + WooCommerce + PHPCompatibility 8.0-)
composer run analyze   # PHPStan con stub WooCommerce
find . -path ./vendor -prune -o -name '*.php' -print0 | xargs -0 -n1 php -l   # syntax check
```

## Definition of done

- `php -l`, `composer run lint` e `composer run analyze` puliti.
- Flusso di recesso verificato end-to-end (dichiarazione → conferma → avviso + PDF).
- Conformità all'art. 54-bis preservata; nuove stringhe tradotte e `.pot` aggiornato.
- Niente dipendenze runtime aggiunte senza esplicita decisione.

## Voce del progetto

Comunicazione tecnica, sobria, in italiano. Il progetto è di WAYT: commit convenzionali (`feat:`, `fix:`, `docs:`, `refactor:`, `chore:`), nessun riferimento a strumenti di generazione nei messaggi di commit o nel codice.
