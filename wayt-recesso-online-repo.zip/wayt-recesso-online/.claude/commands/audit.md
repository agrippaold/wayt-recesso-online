# /audit — Audit totale del plugin + proposta feature/fix

Esegui un audit completo di **WAYT Recesso Online** e produci report e piani azionabili. Non modificare il codice finché non te lo chiedo esplicitamente nella fase 4.

## Fase 0 — Setup e sanity

1. Leggi `CLAUDE.md`, `wayt-recesso-online.php`, `includes/class-wayt-recesso-pdf.php`, `uninstall.php`, `readme.txt`.
2. `composer install` se `vendor/` non esiste.
3. Esegui e raccogli output di:
   - `find . -path ./vendor -prune -o -name '*.php' -print0 | xargs -0 -n1 php -l`
   - `composer run lint` (PHPCS)
   - `composer run analyze` (PHPStan)
4. Genera/verifica il `.pot`: ogni stringa utente deve essere internazionalizzata con text domain `wayt-recesso`.

## Fase 1 — Audit per aree (con prove)

Per ogni finding cita **file:riga** e una motivazione. Aree:

1. **Sicurezza WordPress**
   - Sanitizzazione input (`$_GET/$_POST/$_REQUEST`), `wp_unslash`, escape output, query preparate (`$wpdb->prepare`).
   - Nonce + capability su tutte le azioni che cambiano stato e sugli handler `admin-post` (`handle_export_csv`, `handle_request_action`, `handle_pdf_download`).
   - `handle_pdf_download`: verifica assenza di IDOR/path traversal, header corretti, nessun leak cross-order.
   - Accesso diretto ai file (`ABSPATH`), scrittura su filesystem in `generate_pdf_file` (permessi, cleanup, race).
   - Validità e robustezza del generatore PDF su input ostili (stringhe lunghe, caratteri di controllo, UTF-8 multibyte): verifica che l'output resti un PDF valido.
2. **Coding standards e compatibilità**
   - PHPCS WordPress-Extra pulito; PHPCompatibility per PHP 8.0–8.3.
   - Niente funzioni deprecate WP/WC; uso corretto delle API WooCommerce (CRUD ordini, refund).
3. **Correttezza e logica**
   - Calcolo decorrenza/scadenza recesso, fusi orari, `is_eligible`, `order_fully_excluded`, esclusioni art. 59 (incluse variazioni e categorie).
   - `maybe_refund`: importi (totale vs articoli), tasse, idempotenza, gestione errori.
   - Idempotenza del flusso (token, transient lock), doppio invio, ordini ospite vs loggati.
4. **Compatibilità WooCommerce**
   - HPOS (nessun accesso diretto a postmeta dove serve l'API), checkout a blocchi (`inject_blocks_notice`), temi a blocchi, ultime versioni WC/WP.
5. **Conformità art. 54-bis** (verifica l'implementazione rispetto a questa checklist e segnala scostamenti)
   - c.1–2 funzione sempre accessibile + etichetta corretta;
   - c.3 dichiarazione con nome, identificativo ordine, mezzo elettronico;
   - c.4 comando di conferma separato;
   - c.6 avviso su supporto durevole con contenuto + data/ora;
   - c.7 validità entro la scadenza;
   - art.49 lett.h informativa precontrattuale + modulo tipo;
   - art.59 eccezioni.
6. **i18n & Accessibilità**
   - Copertura traduzioni; form accessibile (label associate, focus, ARIA, contrasto del colore accent configurabile).
7. **Performance**
   - Query nel registro e in `is_item_excluded`/`order_fully_excluded` (chiamate ripetute, caching), opzioni in autoload, hook eseguiti a ogni render.

## Fase 2 — `AUDIT_REPORT.md`

Crea `AUDIT_REPORT.md` con:
- sintesi esecutiva (stato generale, conteggio finding per severità);
- tabella dei finding: `ID | Area | Severità (P0/P1/P2/P3) | File:riga | Descrizione | Raccomandazione`;
- output sintetico di `php -l`, PHPCS, PHPStan.
Severità: **P0** sicurezza/conformità/perdita dati; **P1** bug funzionale; **P2** robustezza/compatibilità; **P3** stile/nice-to-have.

## Fase 3 — `ROADMAP.md` (proposta feature)

Crea `ROADMAP.md` con funzioni proposte, ciascuna con: valore per l'utente, complessità (S/M/L), rischio, impatto sulla conformità. Considera almeno: PDF multipagina e brandizzato, WC_Email registrata nel pannello Email, traduzioni (it/en/de), blocco Gutenberg per il form, statistiche nella dashboard, integrazione con i principali plugin "data di consegna", esportazione PDF in blocco, test automatici (PHPUnit + wp-env), webhook/REST per gestionali. Ordina per rapporto valore/rischio.

## Fase 4 — Fix (solo su conferma)

Fermati e presentami `AUDIT_REPORT.md` e `ROADMAP.md`. Quando ti do l'ok, implementa **solo i P0/P1** su un branch `audit/fixes`, un commit per finding (`fix: …`), senza aggiungere dipendenze runtime e mantenendo lint/PHPStan puliti. Aggiorna il `.pot` se tocchi stringhe.

## Vincoli

- Niente dipendenze runtime nuove senza chiedere.
- Mantieni la compatibilità HPOS e PHP 8.0.
- Commit convenzionali; nessun riferimento a strumenti di generazione nei messaggi.
