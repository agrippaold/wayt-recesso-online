# WAYT Recesso Online

Funzione di recesso digitale per WooCommerce conforme all'**art. 54-bis del Codice del Consumo** (D.Lgs 209/2025, recepimento Dir. UE 2023/2673), applicabile **dal 19 giugno 2026** ai contratti conclusi a distanza.

Il plugin aggiunge un pulsante **"Recedi dal contratto qui"** sempre accessibile, un flusso a due passaggi (dichiarazione → conferma), l'invio di un **avviso di ricevimento su supporto durevole** (con **PDF attestato** allegato) e un **registro** delle richieste con export CSV. Include esclusioni per le **eccezioni art. 59**, **motivi configurabili**, **rimborso WooCommerce opzionale**, nota precontrattuale anche sul **checkout a blocchi**, e personalizzazione grafica. Nessuna dipendenza esterna, compatibile **HPOS**.

> **Nota legale.** Questo plugin implementa la parte **tecnica** dell'art. 54-bis. Le condizioni generali di vendita, l'informativa precontrattuale completa (art. 49) e il modulo tipo di recesso (Allegato I, parte B) restano responsabilità del professionista e del suo consulente legale. Il plugin fornisce i ganci per pubblicarli, non li redige.

---

## Requisiti

- WordPress ≥ 6.2
- WooCommerce ≥ 7.0 (testato fino a 9.9)
- PHP ≥ 8.0

## Installazione

1. Carica la cartella `wayt-recesso-online/` in `wp-content/plugins/` (oppure installa lo ZIP da **Plugin → Aggiungi nuovo → Carica plugin**).
2. Attiva il plugin. All'attivazione vengono creati automaticamente:
   - la tabella del registro (`{prefix}wayt_recesso_requests`);
   - una pagina **"Recesso"** contenente lo shortcode `[wayt_recesso]`;
   - le impostazioni di default.
3. Vai su **WooCommerce → Recesso online** per configurare finestra, trigger e testi.

## Configurazione rapida

| Impostazione | Default | Note |
|---|---|---|
| Giorni di recesso | `14` | Durata della finestra. |
| Inizio del periodo (trigger) | `Data completamento ordine` | Alternative: data pagamento, data ordine, **meta data di consegna**. |
| Chiave meta data di consegna | `_delivery_date` | Usata solo se il trigger è "meta di consegna". **Da allineare al campo realmente usato dal sito** (es. plugin di spedizione/booking). |
| Stati ordine ammessi | `In lavorazione`, `Completato` | Solo gli ordini in questi stati mostrano il pulsante. |
| Stato dopo il recesso | `Recesso richiesto` | Alternative: `In sospeso`, oppure nessun cambio di stato. |
| Recesso parziale | Attivo | Permette di selezionare i singoli articoli. |
| Motivazione | Attiva (facoltativa per il cliente) | Il recesso non richiede motivazione: il campo resta opzionale. |
| Nota al checkout | Attiva | Mostra l'informativa precontrattuale prima dell'invio dell'ordine (checkout **classico** e **a blocchi**, gestibili separatamente). |
| URL modulo tipo | — | Link al modulo Allegato I parte B. |
| **PDF attestato** | Attivo | Allega all'avviso un PDF della dichiarazione (supporto durevole) e lo rende scaricabile dal registro. Generato senza servizi esterni. |
| **Rimborso automatico** | Disattivato | `off` / rimborso degli articoli oggetto di recesso / rimborso totale. Crea un rimborso WooCommerce **senza** contattare il gateway (`refund_payment = false`). |
| **Motivi configurabili** | — | Una motivazione per riga → il campo diventa un menu a tendina con opzione «Altro». Vuoto = testo libero. |
| **Esclusioni art. 59** | — | ID prodotti e/o slug categorie esclusi dal recesso, oppure checkbox «Escluso dal recesso» sulla singola scheda prodotto. |
| **Colore principale / CSS** | `#111111` | Accent del pulsante di conferma + CSS personalizzato per le pagine del form. |
| **Mittente / Reply-To / testo avviso** | — | Personalizzazione dell'email di avviso (nome mittente, indirizzo risposta, paragrafo introduttivo). |

> Il **trigger** del decorrere dei 14 giorni dipende dal modello di business: per beni fisici la norma fa decorrere il termine dalla **consegna**; se il sito traccia la consegna in un campo dedicato, impostare il trigger su "meta di consegna" e indicare la chiave corretta. Per servizi/digitale valutare data pagamento o completamento con il legale.

## Shortcode

- `[wayt_recesso]` — la funzione di recesso completa (lookup ordine per ospiti, oppure apertura diretta tramite link sicuro con `order_key`; dichiarazione + conferma). Va su una pagina pubblica dedicata (creata in automatico).
- `[wayt_recesso_info]` — blocco informativo precontrattuale + link al modulo tipo. Da inserire nelle pagine "Termini", "Diritto di recesso", o **nel checkout a blocchi** dove la nota automatica non compare (vedi limiti).

## Mappatura art. 54-bis → implementazione

Riferimento per la difendibilità della conformità e per l'handover al cliente.

| Requisito normativo | Comma | Implementazione |
|---|---|---|
| Funzione di recesso **sempre visibile e accessibile** per tutta la durata del periodo, etichettata "Recedere dal contratto qui" o equivalente | c. 1–2 | Pulsante **"Recedi dal contratto qui"** in *Il mio account → Ordini*, nel dettaglio ordine e nelle email ordine; pagina pubblica con `[wayt_recesso]`; il pulsante compare solo finché l'ordine è eleggibile (entro la finestra). Etichetta personalizzabile. |
| Dichiarazione online che consente di fornire/confermare: **(a)** nome del consumatore, **(b)** informazioni che identificano il contratto/ordine, **(c)** mezzo elettronico per ricevere la conferma | c. 3 | Step "dichiarazione": campo **nome**, **identificativo ordine** (numero + verifica `order_key`/email), campo **email** per l'avviso di ricevimento. In più: selezione articoli (recesso parziale) e motivazione facoltativa. |
| **Comando di conferma** separato e inequivocabile | c. 4 | Secondo step con riepilogo e pulsante dedicato **"Conferma recesso"** (etichetta personalizzabile), protetto da nonce e token anti-doppio invio. |
| **Avviso di ricevimento** del recesso su **supporto durevole**, con **contenuto** della dichiarazione, **data e ora**, senza indebito ritardo | c. 6 | Email automatica al consumatore tramite il mailer di WooCommerce (supporto durevole), con testo della dichiarazione, articoli, data e ora di ricezione, e **PDF attestato allegato** (generato senza dipendenze esterne). Mittente/Reply-To e testo introduttivo personalizzabili. Hook `wayt_recesso/attachments` per ulteriori allegati. Notifica parallela al commerciante. |
| Recesso **valido se trasmesso prima della scadenza** | c. 7 | Il pulsante e il flusso sono disponibili solo entro la finestra calcolata; data/ora di invio registrate nel log. |
| **Eccezioni al diritto di recesso** (beni su misura, sigillati aperti, deperibili, ecc.) | art. 59 | Esclusioni per ID prodotto, slug categoria o checkbox di prodotto: gli articoli esclusi non sono selezionabili e, se l'intero ordine è escluso, il pulsante non compare. *La qualificazione delle eccezioni va validata dal legale.* |
| **Informativa precontrattuale**: esistenza e collocazione della funzione **prima** della conclusione del contratto + modulo tipo | art. 49 c.1 lett. h | Nota al checkout **classico e a blocchi** + shortcode `[wayt_recesso_info]` + campo URL del modulo tipo. *Il testo va validato dal legale.* |
| **Tracciabilità / prova** | — | Registro `{prefix}wayt_recesso_requests` (nome, email, ambito, articoli, motivazione, testo dichiarazione, IP, data/ora, stato avviso) + export CSV + nota privata sull'ordine. |

## Hook per gli sviluppatori

```php
// Dopo una conferma di recesso andata a buon fine.
do_action( 'wayt_recesso/confermato', int $request_id, WC_Order $order, array $data );

// Allegati all'avviso di ricevimento (es. PDF della dichiarazione).
apply_filters( 'wayt_recesso/attachments', array $files, WC_Order $order, array $data );
```

Esempio (rimborso/automazioni a valle del recesso):

```php
add_action( 'wayt_recesso/confermato', function ( $request_id, $order, $data ) {
    // Es. creare un rimborso, notificare il gestionale, ecc.
}, 10, 3 );
```

## Limiti noti

- **Rimborso e gateway.** Il rimborso automatico crea il rimborso *in WooCommerce* ma **non** contatta il gateway di pagamento (`refund_payment = false`): il rimborso effettivo al cliente va processato dal pannello/PSP. Scelta voluta per evitare movimentazioni automatiche di denaro non verificate. In caso di recesso entro 14 giorni vanno comunque rimborsate le spese di spedizione standard: voce da gestire manualmente.
- **Disdetta abbonamenti ≠ recesso.** Il plugin copre il **recesso** (art. 52, ~14 giorni); non gestisce la disdetta di contratti a esecuzione periodica.
- **Trigger di consegna:** se si usa il decorrere dalla consegna, occorre che il sito salvi la data in un meta dell'ordine e che la chiave sia indicata in impostazioni.
- **Checkout a blocchi:** la nota precontrattuale viene iniettata lato server sopra l'area "Effettua ordine". Con temi/checkout fortemente personalizzati verificarne il posizionamento; in alternativa resta disponibile lo shortcode `[wayt_recesso_info]`.
- **PDF attestato:** documento di testo essenziale a pagina singola (font core, layout fisso); pensato come prova di trasmissione, non come documento brandizzato. L'email resta comunque un supporto durevole valido anche senza PDF.
- **Registro per-sito:** in multisite la tabella del registro è creata per singolo sito attivo.

## Disinstallazione

Per scelta di compliance, alla disinstallazione:

- vengono **sempre** rimosse le impostazioni e i lock temporanei;
- il **registro dei recessi** e i meta sugli ordini vengono rimossi **solo** se è stata attivata l'opzione *"Elimina anche il registro recessi e i dati alla disinstallazione"* (default: **disattivata**, perché il registro è una prova di conformità);
- la pagina pubblica con lo shortcode **non** viene eliminata (è contenuto del sito).

## Changelog

### 0.2.0
- **PDF attestato** del recesso allegato all'avviso di ricevimento e scaricabile dal registro (generatore PDF interno, senza dipendenze esterne).
- **Esclusioni art. 59**: per ID prodotto, slug categoria o checkbox sulla scheda prodotto; gli articoli esclusi non sono recedibili e bloccano il pulsante se coprono l'intero ordine.
- **Motivi di recesso configurabili** (menu a tendina con opzione «Altro»).
- **Rimborso automatico opzionale** (articoli o totale) tramite `wc_create_refund`, senza contatto automatico col gateway.
- **Nota precontrattuale sul checkout a blocchi** (iniezione lato server, senza build JS).
- **Email avviso personalizzabile**: nome mittente, Reply-To, testo introduttivo.
- **Personalizzazione grafica**: colore principale + CSS personalizzato.
- File **`languages/wayt-recesso.pot`** per la traduzione.

### 0.1.0
- Prima release: pulsante di recesso, flusso dichiarazione + conferma, recesso totale/parziale, avviso di ricevimento su supporto durevole, registro + export CSV, stato ordine "Recesso richiesto", nota precontrattuale al checkout, pannello di conformità, compatibilità HPOS.
